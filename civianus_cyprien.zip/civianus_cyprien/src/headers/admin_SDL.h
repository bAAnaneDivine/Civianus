#ifndef _ADMIN_SDL_H_
#define _ADMIN_SDL_H_

void SDL_ExitWithError(const char* message);
void SDL_initialisation();

#endif