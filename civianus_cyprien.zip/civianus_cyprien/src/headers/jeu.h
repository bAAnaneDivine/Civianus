#ifndef JEU_H_
#define JEU_H_

int jeu(int civilization,SDL_Window* window, SDL_Renderer* renderer,int liste_cases[N][N]);

#endif
