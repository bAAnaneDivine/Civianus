#ifndef _MENU_H_
#define _MENU_H_

void menu(SDL_Window* window, SDL_Renderer* renderer, SDL_Rect rectangle_restart, SDL_Rect rectangle_continuer, SDL_Rect rectangle_quit, SDL_Rect fenetre_surface);
void menu_select(SDL_Window* window, SDL_Renderer* renderer, SDL_Rect rect_trajan, SDL_Rect rect_pierre, SDL_Rect rect_Barberousse);

#endif
