/*
* boutons ville et informations
*/
SDL_Rect rectangle_colon; //choix_ville creation colon
SDL_Rect rectangle_batisseur; //choix_ville creation batisseur
SDL_Rect rectangle_guerrier;//choix_ville creation guerrier
SDL_Rect rectangle_arm_long;//choix_ville creation armée_longue
SDL_Rect rectangle_arm_spec;//choix_ville creation armée_specifique
SDL_Rect rectangle_culture;//choix_ville informations culture
SDL_Rect rectangle_sciences;//choix_ville informations sciences
SDL_Rect rectangle_nom_ville;//choix_ville informations nom_ville
SDL_Rect rectangle_niveau_ville;//choix_ville informations niveau_ville

/*
* boutons colon
*/
SDL_Rect creer_ville;//choix colon creation ville
/*
* boutons batisseur
*/
SDL_Rect creer_ferme;//choix batisseur creation ferme
SDL_Rect nbr_coup_rest;//choix batisseur nombre de construction restantes
/*
* boutons guerrier
*/
SDL_Rect attaque_guerrier;//choix guerrier attaque
SDL_Rect pdv;//informations points de vie restants
SDL_Rect attaque;//informations points d'attaque
SDL_Rect defense;//informations points de defense
/*
* boutons arm_long
*/
SDL_Rect attaque_arm_long;//choix arm_long attaque
SDL_Rect pdv;//informations points de vie restants
SDL_Rect attaque;//informations points d'attaque
SDL_Rect defense;//informations points de defense
/*
* boutons arm_spec
*/
SDL_Rect attaque_arm_spec;//choix arm_spec attaque
SDL_Rect pdv;//informations points de vie restants
SDL_Rect attaque;//informations points d'attaque
SDL_Rect defense;//informations points de defense



void * fonction_choix(int choix){
 /*
      return(void* structure en focntion du choix);
 */


}
