var searchData=
[
  ['plateau_2ec_0',['plateau.c',['../plateau_8c.html',1,'']]]
];
