var searchData=
[
  ['sdl_5fafficheruneimage_0',['SDL_AfficherUneImage',['../plateau_8c.html#ace1d99c84ba4d63d95dd6ef643f99f7e',1,'plateau.c']]],
  ['sdl_5fexitwitherror_1',['SDL_ExitWithError',['../admin___s_d_l_8c.html#abed124ab111ee095d48f08e2a3ea4446',1,'admin_SDL.c']]],
  ['sdl_5finitialisation_2',['SDL_initialisation',['../admin___s_d_l_8c.html#aab9ebef628e934459c6bb214ff17bdb5',1,'admin_SDL.c']]]
];
