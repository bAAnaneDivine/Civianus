var searchData=
[
  ['clean_5fressources_0',['clean_ressources',['../plateau_8c.html#ab5a05aef8d835e7085556a2ef01f8710',1,'plateau.c']]],
  ['crea_5fplat_1',['crea_plat',['../plateau_8c.html#a77d97ee32158cb8e63cf3d04e1db7513',1,'plateau.c']]]
];
