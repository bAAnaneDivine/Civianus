var searchData=
[
  ['colon_5ft_0',['colon_t',['../structcolon__t.html',1,'']]]
];
