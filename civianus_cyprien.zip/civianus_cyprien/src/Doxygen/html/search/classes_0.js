var searchData=
[
  ['arm_5flong_0',['arm_long',['../structarm__long.html',1,'']]],
  ['arm_5fspec_1',['arm_spec',['../structarm__spec.html',1,'']]]
];
