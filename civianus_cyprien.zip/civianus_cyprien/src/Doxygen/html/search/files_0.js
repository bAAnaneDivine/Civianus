var searchData=
[
  ['admin_5fsdl_2ec_0',['admin_SDL.c',['../admin___s_d_l_8c.html',1,'']]]
];
